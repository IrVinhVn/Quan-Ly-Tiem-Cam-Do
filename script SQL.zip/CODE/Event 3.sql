-- EVENT 3: XỬ LÝ TRẢ NỢ VÀ HOÀN TRẢ TÀI SẢN

CREATE OR ALTER PROCEDURE sp_XuLyTraNo
    @MaHD VARCHAR(20),
    @SoTienTra DECIMAL(18,0),
    @MaPhieu VARCHAR(20) 
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @Today DATE = GETDATE();
    DECLARE @TongNoHienTai DECIMAL(18,0);
    DECLARE @TinhTrangHD NVARCHAR(50);
    DECLARE @Deadline2 DATE;
    DECLARE @MaBD VARCHAR(20) = 'BD' + CAST(ABS(CHECKSUM(NEWID())) % 1000000 AS VARCHAR);

    SELECT @TinhTrangHD = TinhTrang, @Deadline2 = Deadline2
    FROM HOPDONG WHERE MaHD = @MaHD;

    IF EXISTS (SELECT 1 FROM TAISAN WHERE MaHD = @MaHD AND IsSold = 1)
    BEGIN
        PRINT N'THÔNG BÁO: Tài sản đã bị thanh lý. Không thu tiền, không trả đồ.';
        RETURN;
    END

    SET @TongNoHienTai = dbo.fn_CalcMoneyContract(@MaHD, @Today);

    BEGIN TRY
        BEGIN TRANSACTION;

        DECLARE @TienLaiThucTe DECIMAL(18,0) = @TongNoHienTai - (SELECT TienVayGoc - ISNULL(SUM(TienGocThu),0) FROM PHIEUTHU RIGHT JOIN HOPDONG ON PHIEUTHU.MaHD = HOPDONG.MaHD WHERE HOPDONG.MaHD = @MaHD GROUP BY TienVayGoc);
        INSERT INTO PHIEUTHU (MaPhieu, MaHD, NgayDong, TienGocThu, TienLaiThu)
        VALUES (@MaPhieu, @MaHD, GETDATE(), @SoTienTra, 0); 

        DECLARE @DuNoConLai DECIMAL(18,0) = @TongNoHienTai - @SoTienTra;
        DECLARE @TrangThaiMoi NVARCHAR(50);

        IF @DuNoConLai <= 0
        BEGIN
            SET @TrangThaiMoi = N'Đã thanh toán đủ';
            UPDATE TAISAN SET TrangThai = N'Đã trả khách' WHERE MaHD = @MaHD AND TrangThai = N'Đang cầm cố';
        END
        ELSE
        BEGIN
            SET @TrangThaiMoi = N'Đang trả góp';
        END

        UPDATE HOPDONG SET TinhTrang = @TrangThaiMoi WHERE MaHD = @MaHD;

        INSERT INTO LICHSUBIENDONG (MaBD, MaHD, NgayTao, LoaiBienDong, SoTienDaTra, DuNoHienTai, TrangThaiMoi, GhiChu)
        VALUES (@MaBD, @MaHD, GETDATE(), N'Thu nợ', @SoTienTra, @DuNoConLai, @TrangThaiMoi, N'Khách trả nợ tại quầy');

        PRINT N'--- DANH SÁCH TÀI SẢN CÓ THỂ TRẢ LẠI ---';
        
        DECLARE @TongGiaTriTaiSanDangCam DECIMAL(18,0);
        SELECT @TongGiaTriTaiSanDangCam = SUM(DinhGia) FROM TAISAN WHERE MaHD = @MaHD AND TrangThai = N'Đang cầm cố';
        SELECT MaTS, TenTS, DinhGia, 
               (@TongGiaTriTaiSanDangCam - DinhGia) AS GiaTriConLaiNeuTraMonNay
        FROM TAISAN
        WHERE MaHD = @MaHD 
          AND TrangThai = N'Đang cầm cố'
          AND (@TongGiaTriTaiSanDangCam - DinhGia) >= @DuNoConLai;

        COMMIT TRANSACTION;
        PRINT N'Xử lý giao dịch thành công.';

    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        DECLARE @Err NVARCHAR(MAX) = ERROR_MESSAGE();
        RAISERROR(@Err, 16, 1);
    END CATCH
END
GO