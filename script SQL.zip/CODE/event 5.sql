-- EVENT 5: QUẢN LÝ THANH LÝ TÀI SẢN (TRIGGER)
CREATE OR ALTER TRIGGER trg_QuanLyThanhLyTaiSan
ON HOPDONG
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF UPDATE(TinhTrang)
    BEGIN
        UPDATE TS
        SET TS.TrangThai = N'Đã bán thanh lý',
            TS.IsSold = 1  
        FROM TAISAN TS
        INNER JOIN inserted i ON TS.MaHD = i.MaHD
        INNER JOIN deleted d ON i.MaHD = d.MaHD
        WHERE i.TinhTrang = N'Đã thanh lý' 
          AND d.TinhTrang <> N'Đã thanh lý'
          AND TS.TrangThai = N'Sẵn sàng thanh lý'; 
    END

    UPDATE H
    SET H.TinhTrang = N'Quá hạn (nợ xấu)'
    FROM HOPDONG H
    INNER JOIN inserted i ON H.MaHD = i.MaHD
    WHERE H.TinhTrang = N'Đang vay' 
      AND CAST(GETDATE() AS DATE) > H.Deadline1;

    UPDATE TS
    SET TS.TrangThai = N'Sẵn sàng thanh lý'
    FROM TAISAN TS
    INNER JOIN HOPDONG H ON TS.MaHD = H.MaHD
    INNER JOIN inserted i ON H.MaHD = i.MaHD
    WHERE H.TinhTrang = N'Quá hạn (nợ xấu)' 
      AND CAST(GETDATE() AS DATE) > H.Deadline2
      AND TS.TrangThai = N'Đang cầm cố';

END
GO