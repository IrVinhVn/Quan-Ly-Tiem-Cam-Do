DECLARE @ThongTinTaiSan NVARCHAR(MAX) = N'[
    {
        "MaTS": "TS001",
        "MaLoai": "L01",
        "TenTS": "Xe máy Honda SH 150i",
        "DinhGia": 60000000
    },
    {
        "MaTS": "TS002",
        "MaLoai": "L02",
        "TenTS": "Điện thoại iPhone 15 Pro Max",
        "DinhGia": 25000000
    }
]';

EXEC sp_TaoHopDongMoi 
    @MaKH = 'KH001',
    @CCCD = '001099000123',
    @HoTen = N'Nguyễn Văn A',
    @SDT = '0987654321',
    @DiaChi = N'Hà Nội',
    @NgaySinh = '1990-05-15',
    
    @MaHD = 'HD001',
    @MaNV = 'NV001', 
    @TienVayGoc = 20000000, 
    @NgayVay = '2023-10-01',
    @SoNgayDenHan1 = 30, 
    @SoNgayChoThanhLy = 15, 
    
    @DanhSachTaiSanJSON = @ThongTinTaiSan;


SELECT * FROM KHACHHANG WHERE MaKH = 'KH001';
SELECT * FROM HOPDONG WHERE MaHD = 'HD001';
SELECT * FROM TAISAN WHERE MaHD = 'HD001';
SELECT * FROM LICHSUBIENDONG WHERE MaHD = 'HD001';