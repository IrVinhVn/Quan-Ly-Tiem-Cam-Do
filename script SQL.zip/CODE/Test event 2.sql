USE QuanLyCamDo;
GO
IF NOT EXISTS (SELECT 1 FROM KEHOACHTRAGOP WHERE MaKHG = 'KHG001')
BEGIN
    INSERT INTO KEHOACHTRAGOP (MaKHG, MaHD, NgayHen, TienGocPhaiTra, TienLaiPhaiTra, TrangThai)
    VALUES ('KHG001', 'HD001', '2023-10-15', 5000000, 1500000, N'Chưa đóng');
END
SELECT dbo.fn_CalcMoneyTransaction('KHG001', '2023-10-15') AS TienKyTraGop_KHG001;
SELECT dbo.fn_CalcMoneyContract('HD001', '2023-10-16') AS TongNo_LaiDon_15Ngay;
SELECT dbo.fn_CalcMoneyContract('HD001', '2023-11-05') AS TongNo_LaiKep_5NgayTre;