EXEC sp_GiaHanHopDong 
    @MaHopDong = 'HD001', 
    @MaNhanVien = 'NV001', 
    @SoNgayGiaHan = 30;

SELECT MaHD, NgayVay, Deadline1, Deadline2, TinhTrang 
FROM HOPDONG WHERE MaHD = 'HD001';

SELECT NgayTao, LoaiBienDong, SoTienDaTra, DuNoHienTai, MaNhanVien, GhiChu 
FROM LICHSUBIENDONG WHERE MaHD = 'HD001' 
ORDER BY NgayTao DESC;