ALTER TABLE LICHSUBIENDONG 
ADD MaNhanVien VARCHAR(20);
GO

ALTER TABLE LICHSUBIENDONG 
ADD CONSTRAINT FK_LOG_NHANVIEN FOREIGN KEY (MaNhanVien) REFERENCES NHANVIEN(MaNV);
GO

CREATE OR ALTER PROCEDURE sp_GiaHanHopDong
    @MaHopDong VARCHAR(20),  
    @MaNhanVien VARCHAR(20), 
    @SoNgayGiaHan INT = 30   
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Today DATE = GETDATE();

    DECLARE @TienVayGoc DECIMAL(18,0);
    DECLARE @DaTraGoc DECIMAL(18,0);
    DECLARE @TongTienHienTai DECIMAL(18,0);
    
    SELECT @TienVayGoc = TienVayGoc FROM HOPDONG WHERE MaHD = @MaHopDong;
    
    SELECT @DaTraGoc = ISNULL(SUM(TienGocThu), 0) FROM PHIEUTHU WHERE MaHD = @MaHopDong;
    
    DECLARE @DuNoGoc DECIMAL(18,0) = @TienVayGoc - @DaTraGoc;
    
    SET @TongTienHienTai = dbo.fn_CalcMoneyContract(@MaHopDong, @Today);
    
    DECLARE @TienLaiPhaiTra DECIMAL(18,0) = @TongTienHienTai - @DuNoGoc;

    IF @TienLaiPhaiTra <= 0
    BEGIN
        PRINT N'THÔNG BÁO: Không có tiền lãi phát sinh, chưa cần đóng tiền gia hạn.';
        RETURN;
    END

    BEGIN TRY
        BEGIN TRANSACTION;

        DECLARE @MaPhieu VARCHAR(20) = 'PTGH' + CAST(ABS(CHECKSUM(NEWID())) % 10000 AS VARCHAR);
        
        INSERT INTO PHIEUTHU (MaPhieu, MaHD, NgayDong, TienGocThu, TienLaiThu)
        VALUES (@MaPhieu, @MaHopDong, GETDATE(), 0, @TienLaiPhaiTra);

        DECLARE @NewDeadline1 DATE = DATEADD(DAY, @SoNgayGiaHan, @Today);
        DECLARE @NewDeadline2 DATE = DATEADD(DAY, 15, @NewDeadline1); 

        UPDATE HOPDONG
        SET Deadline1 = @NewDeadline1,
            Deadline2 = @NewDeadline2,
            TinhTrang = N'Đang vay' 
        WHERE MaHD = @MaHopDong;

        DECLARE @MaBienDong VARCHAR(20) = 'BDGH' + CAST(ABS(CHECKSUM(NEWID())) % 10000 AS VARCHAR);
        
        INSERT INTO LICHSUBIENDONG (MaBD, MaHD, NgayTao, LoaiBienDong, SoTienDaTra, DuNoHienTai, TrangThaiMoi, GhiChu, MaNhanVien)
        VALUES (@MaBienDong, @MaHopDong, GETDATE(), N'Gia hạn hợp đồng', @TienLaiPhaiTra, @DuNoGoc, N'Đang vay', N'Đóng trọn tiền lãi để dời ngày', @MaNhanVien);

        COMMIT TRANSACTION;
        PRINT N'=================================================';
        PRINT N'GIA HẠN THÀNH CÔNG!';
        PRINT N'Số tiền lãi khách đã đóng: ' + FORMAT(@TienLaiPhaiTra, '#,##0') + N' VNĐ';
        PRINT N'Mốc Deadline 1 mới: ' + CAST(@NewDeadline1 AS VARCHAR);
        PRINT N'=================================================';

    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        DECLARE @Err NVARCHAR(MAX) = ERROR_MESSAGE();
        RAISERROR(@Err, 16, 1);
    END CATCH
END
GO