-- EVENT 1: ĐĂNG KÝ HỢP ĐỒNG MỚI (VAY TIỀN)
CREATE OR ALTER PROCEDURE sp_TaoHopDongMoi
    @MaKH VARCHAR(20),
    @CCCD VARCHAR(12),
    @HoTen NVARCHAR(100),
    @SDT VARCHAR(15),
    @DiaChi NVARCHAR(255),
    @NgaySinh DATE,

    @MaHD VARCHAR(20),
    @MaNV VARCHAR(20),
    @TienVayGoc DECIMAL(18,0),
    @NgayVay DATE,
    @MucLaiSuat DECIMAL(18,0) = 5000,
    @SoNgayDenHan1 INT = 30, 
    @SoNgayChoThanhLy INT = 15, 

    @DanhSachTaiSanJSON NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        BEGIN TRANSACTION;
        IF NOT EXISTS (SELECT 1 FROM KHACHHANG WHERE CCCD = @CCCD)
        BEGIN
            INSERT INTO KHACHHANG (MaKH, CCCD, HoTen, SDT, DiaChi, NgaySinh)
            VALUES (@MaKH, @CCCD, @HoTen, @SDT, @DiaChi, @NgaySinh);
        END
        ELSE
        BEGIN
            SELECT @MaKH = MaKH FROM KHACHHANG WHERE CCCD = @CCCD;
        END

        DECLARE @Deadline1 DATE = DATEADD(DAY, @SoNgayDenHan1, @NgayVay);
        DECLARE @Deadline2 DATE = DATEADD(DAY, @SoNgayChoThanhLy, @Deadline1);

        INSERT INTO HOPDONG (MaHD, MaKH, MaNV, TienVayGoc, NgayVay, Deadline1, Deadline2, MucLaiSuat, TinhTrang)
        VALUES (@MaHD, @MaKH, @MaNV, @TienVayGoc, @NgayVay, @Deadline1, @Deadline2, @MucLaiSuat, N'Đang vay');

        INSERT INTO TAISAN (MaTS, MaHD, MaLoai, TenTS, DinhGia, TrangThai, IsSold)
        SELECT 
            JSON_VALUE(value, '$.MaTS'),
            @MaHD,
            JSON_VALUE(value, '$.MaLoai'),
            JSON_VALUE(value, '$.TenTS'),
            CAST(JSON_VALUE(value, '$.DinhGia') AS DECIMAL(18,0)),
            N'Đang cầm cố',
            0 -- IsSold = 0 
        FROM OPENJSON(@DanhSachTaiSanJSON);
        DECLARE @MaBD VARCHAR(20) = 'BD' + CAST(ABS(CHECKSUM(NEWID())) % 1000000 AS VARCHAR); -- Random ID tạm

        INSERT INTO LICHSUBIENDONG (MaBD, MaHD, NgayTao, LoaiBienDong, SoTienDaTra, DuNoHienTai, TrangThaiMoi, GhiChu)
        VALUES (@MaBD, @MaHD, GETDATE(), N'Giải ngân', 0, @TienVayGoc, N'Đang vay', N'Khởi tạo hợp đồng mới');

        COMMIT TRANSACTION;
        PRINT N'Tuyệt vời! Tạo hợp đồng và danh sách tài sản thành công.';

    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR (@ErrorMessage, 16, 1);
    END CATCH
END
GO