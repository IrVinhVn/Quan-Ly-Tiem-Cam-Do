USE QuanLyCamDo;
GO

CREATE OR ALTER FUNCTION fn_CalcMoneyTransaction(
    @TransactionID VARCHAR(20),
    @TargetDate DATE
)
RETURNS DECIMAL(18,0)
AS
BEGIN
    DECLARE @SoTien DECIMAL(18,0) = 0;
    DECLARE @TienGoc DECIMAL(18,0);
    DECLARE @TienLai DECIMAL(18,0);
    DECLARE @TrangThai NVARCHAR(50);

    SELECT @TienGoc = TienGocPhaiTra,
           @TienLai = TienLaiPhaiTra,
           @TrangThai = TrangThai
    FROM KEHOACHTRAGOP
    WHERE MaKHG = @TransactionID;

    IF @TrangThai = N'Đã đóng'
        SET @SoTien = 0;
    ELSE
        SET @SoTien = @TienGoc + @TienLai;

    RETURN @SoTien;
END
GO

CREATE OR ALTER FUNCTION fn_CalcMoneyContract(
    @ContractID VARCHAR(20),
    @TargetDate DATE
)
RETURNS DECIMAL(18,0)
AS
BEGIN
    DECLARE @TienVayGoc DECIMAL(18,0);
    DECLARE @NgayVay DATE;
    DECLARE @Deadline1 DATE;
    DECLARE @MucLaiSuat DECIMAL(18,0);
    DECLARE @DaTraGoc DECIMAL(18,0);

    SELECT @TienVayGoc = TienVayGoc,
           @NgayVay = NgayVay,
           @Deadline1 = Deadline1,
           @MucLaiSuat = MucLaiSuat
    FROM HOPDONG
    WHERE MaHD = @ContractID;

    SELECT @DaTraGoc = ISNULL(SUM(TienGocThu), 0)
    FROM PHIEUTHU
    WHERE MaHD = @ContractID AND CAST(NgayDong AS DATE) <= @TargetDate;

    DECLARE @DuNoHienTai DECIMAL(18,0) = @TienVayGoc - @DaTraGoc;
    IF @DuNoHienTai <= 0 RETURN 0; 

    DECLARE @TongTien DECIMAL(18,0) = 0;
    DECLARE @SoNgayLaiDon INT = 0;
    DECLARE @SoNgayLaiKep INT = 0;

    IF @TargetDate <= @Deadline1
    BEGIN
        SET @SoNgayLaiDon = DATEDIFF(DAY, @NgayVay, @TargetDate);
    END
    ELSE
    BEGIN
        SET @SoNgayLaiDon = DATEDIFF(DAY, @NgayVay, @Deadline1);
        SET @SoNgayLaiKep = DATEDIFF(DAY, @Deadline1, @TargetDate);
    END

    IF @SoNgayLaiDon < 0 SET @SoNgayLaiDon = 0;
    IF @SoNgayLaiKep < 0 SET @SoNgayLaiKep = 0;

    DECLARE @TyLeLai FLOAT = CAST(@MucLaiSuat AS FLOAT) / 1000000.0;
    DECLARE @TienLaiDon DECIMAL(18,0) = @DuNoHienTai * @TyLeLai * @SoNgayLaiDon;

    IF @SoNgayLaiKep = 0
    BEGIN
        SET @TongTien = @DuNoHienTai + @TienLaiDon;
    END
    ELSE
    BEGIN
        DECLARE @GocTinhLaiKep FLOAT = CAST(@DuNoHienTai + @TienLaiDon AS FLOAT);
        DECLARE @TongTienSauLaiKep FLOAT = @GocTinhLaiKep * POWER(1.0 + @TyLeLai, @SoNgayLaiKep);
        SET @TongTien = CAST(@TongTienSauLaiKep AS DECIMAL(18,0));
    END

    RETURN @TongTien;
END
GO