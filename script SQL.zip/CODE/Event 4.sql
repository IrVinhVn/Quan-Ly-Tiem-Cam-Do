-- EVENT 4: TRUY VẤN DANH SÁCH NỢ XẤU (NỢ KHÓ ĐÒI)

CREATE OR ALTER PROCEDURE sp_BaoCaoNoXau
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @Today DATE = GETDATE();
    DECLARE @NextMonth DATE = DATEADD(MONTH, 1, @Today);

    SELECT 
        KH.HoTen AS [Tên KH],
        KH.SDT AS [Số điện thoại],
        HD.TienVayGoc AS [Số tiền vay gốc],
        DATEDIFF(DAY, HD.Deadline1, @Today) AS [Số ngày quá hạn],
        
        dbo.fn_CalcMoneyContract(HD.MaHD, @Today) AS [Tổng tiền phải trả hiện tại],
        dbo.fn_CalcMoneyContract(HD.MaHD, @NextMonth) AS [Tổng số tiền phải trả sau 1 tháng nữa]
        
    FROM HOPDONG HD
    INNER JOIN KHACHHANG KH ON HD.MaKH = KH.MaKH
    
    WHERE HD.Deadline1 < @Today 
      AND HD.TinhTrang NOT IN (N'Đã thanh toán đủ', N'Đã thanh lý');
END
GO